<?php
include("header.php");
?>
<div class="wrapper col1">
  <div id="container">
    <div id="content">
      <h1>Welcome to Online Custmoer Care</h1>
      <p>  Our vision is to exceed customer expectations. We are available, around the clock, to answer your questions and resolve your problems. Please use our help line, email or online feedback form to communicate with us..
.</p>
      <p>If you have any questions or need more information about Our products and services, please contact us on our 24/7 helpline. Our representative will respond to you as soon as possible.</p>
      <p>	Everyone needs to have Medical attention at any time. So we allow every user to register freely at any time..</p>
      <p>Doctor appointment System maintains patient�s prescriptions so that their medical details are always available in Internet, which will be more convenient for the patients. This will be more comfortable for the patient..</p>

      <div class="homecontent">
        <div class="clear"></div>
      </div>
    </div>

    <div class="clear"></div>
  </div>
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5edd2a169e5f6944229012c8/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

	
<?php

include('newFooter.php');

?>
	
 
